<?
namespace app\controllers\admin;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\filters\VerbFilter;
use app\models\leages;

class LeagesController extends Controller
{
	public $enableCsrfValidation = false;
    public function actionIndex()
	{
		if( Yii::$app->user->isGuest ){ echo "Acess denied"; }
		else{
		      $leages = leages::find()->orderBy('id')->asArray()->all();
	          return $this->render('leages',['leages'=>$leages]);
		    }
    }
	//Addleage
	public function actionAddleage()
	{
		$request = Yii::$app->request;
		$post = $request->post();
		$leage = new leages();
		$leage->name = $post['name'];
		$leage->save();
		//render
		$leages = leages::find()->orderBy('id')->asArray()->all();
		return $this->render('leages',['leages'=>$leages]);
	}
	//Deleteleage
	public function actionDeleteleage()
	{
		//delet leages
		$request = Yii::$app->request;
		$post = $request->post();
		$leages = leages::find()->where(['id' => $post['id']])->one();
		if($leages){ $leages->delete(); }
		//render
		$leages = leages::find()->orderBy('id')->asArray()->all();
		return $this->render('leages',['leages'=>$leages]);
	}
	//Changeleage
	public function actionChangeleage()
	{
		$request = Yii::$app->request;
		$post = $request->post();
		$leage = leages::find()->where(['id' => $post['id']])->one();
		if($leage)
		{
		 $leage->name = $post['name'];
		 $leage->update();
		}
	}

}
?>