<?
namespace app\controllers\admin;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\filters\VerbFilter;
//use app\models\users;
//use app\models\leages;

class SeasonsController extends Controller
{
	public $enableCsrfValidation = false;
    public function actionIndex()
	{
	  return $this->render('index');
    }

}
?>