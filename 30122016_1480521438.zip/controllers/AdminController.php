<?
namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\filters\VerbFilter;
use app\models\users;
use app\models\leages;

class AdminController extends Controller
{
	public $enableCsrfValidation = false;
    public function actionIndex()
	{
		if( Yii::$app->user->isGuest ){ return $this->render('logingform'); }
		else{ return $this->render('index'); }
    }
	public function actionLogin()
	{
		$request = Yii::$app->request;
		$post = $request->post();
		$identity = users::findOne([ 'email' => $post['email'],'password' => $post['password'] ]);
		// logs in the user
		if($identity)
		{
			Yii::$app->user->login($identity);
			return $this->render('index');
		}else{
			   return $this->render('logingform');
		     }

	}
	public function actionLogout()
	{
		Yii::$app->user->logout();
		return $this->render('logingform');
	}
}
?>