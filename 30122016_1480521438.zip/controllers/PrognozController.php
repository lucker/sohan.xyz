<?
namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\filters\VerbFilter;
use app\models\prognoz;
use app\models\teams;

class PrognozController extends Controller
{
	public $enableCsrfValidation = false;

	public function actionIndex()
	{
		$p = prognoz::find()->orderBy('id')->asArray()->all();
		
		for($i=0;$i<count($p);$i++)
		{
		 $t1 = teams::find()->where(['id' => $p[$i]['team1']])->one();
		 $t2 = teams::find()->where(['id' => $p[$i]['team2']])->one();
		 $p[$i]['team1'] = $t1->name;
		 $p[$i]['team2'] = $t2->name;
		}
		
		return $this->render('index', ['p'=>$p] );
	}

	public function actionAdd()
	{
      
	}
}
?>