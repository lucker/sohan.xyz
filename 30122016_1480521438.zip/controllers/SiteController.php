<?php

namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\filters\VerbFilter;
use app\models\leages;
use app\models\users;
/*
use app\models\LoginForm;
use app\models\ContactForm;
*/

class SiteController extends Controller
{
    public function actionIndex()
	{
      $leages = leages::find()->orderBy('name')->all();
	  return $this->render('index', ['leages' => $leages]);
    }
	// login
	public function actionLogin()
	{
       $request = Yii::$app->request;
	   $post = $request->post();	   
       $isset = users::find()->where(['email' => $post['email']])->one();
	   if(!$isset)
	   {
	     $user = new users();
	     $user->email = $post['email'];
	     $user->password = $post['password'];
	     $user->save();
	   }else{
		   //пользователь с таким емейл уже зареган
	   }
	  return $this->render('index');
	}
	// registration
	public function actionRegistration()
	{
		return $this->render('registration');
	}
}