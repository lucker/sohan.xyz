<head>
 <meta charset="utf-8">
</head>
<body>
 <div class="container">
   <div align="right">
     <a href="/admin/logout">logout</a>
   </div>
  <h1>Админка</h1>
   <ul class="nav nav-pills">
    <li class="active"><a href="#">Главная</a></li>
    <li><a href="#">Лиги</a></li>
    <li><a href="#">Сизоны</a></li>
	<li><a href="#">Команды</a></li>
   </ul>
 </div>

</body>