<? for($i=0;$i<count($p);$i++){ ?>
 <div class="col-md-12">
	 <div id="title"> 
		 <span style="color:red"><?= $p[$i]['team1'] ?>-<?= $p[$i]['team2'] ?> </span> | <?=  $p[$i]['date'] ?> 
	 </div>
	 <div id="text">
		<?= $p[$i]['text'] ?>
	 </div>
 </div>
<? } ?>