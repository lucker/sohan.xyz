<?
for($i=0;$i<count($leages);$i++)
{
	echo $leages[$i]->name;
}
?>