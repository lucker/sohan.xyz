<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=sohan.mysql.ukraine.com.ua;dbname=sohan_dev',
    'username' => 'sohan_dev',
    'password' => 'fk5m988z',
    'charset' => 'utf8',
];