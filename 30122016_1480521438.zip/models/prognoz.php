<?
namespace app\models;
use yii\db\ActiveRecord;

class prognoz extends ActiveRecord
{
  
  
}
?>