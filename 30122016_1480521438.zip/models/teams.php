<?
namespace app\models;
use yii\db\ActiveRecord;

class teams extends ActiveRecord
{
 
}
?>