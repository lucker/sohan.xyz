<?
namespace app\models;
use yii\db\ActiveRecord;

class seasons extends ActiveRecord
{

}
?>